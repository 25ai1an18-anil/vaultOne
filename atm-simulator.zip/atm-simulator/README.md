# VaultOne – 3D ATM Simulator
Run locally:  npm install  &&  npm start   → http://localhost:3000
Demo cards: 1111222233334444 / PIN 1234  |  5555666677778888 / PIN 4321
Deploy free: push to GitHub → Render.com (Build: npm install, Start: npm start)
